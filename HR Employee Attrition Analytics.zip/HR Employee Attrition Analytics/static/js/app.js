/**
 * Persona HR - Workforce & Attrition Intelligence Platform
 * Frontend Interactive Controller (Chart.js, REST APIs, Power BI Simulator, SQL Sandbox)
 */

document.addEventListener("DOMContentLoaded", () => {
    // Global Application State
    const state = {
        filters: {
            department: "All",
            riskCategory: "All",
            gender: "All",
            overtime: "All"
        },
        directory: {
            page: 1,
            pageSize: 15,
            search: "",
            sortBy: "AttritionRiskScore",
            sortOrder: "desc"
        },
        theme: "dark",
        charts: {}
    };

    // Initialize Application
    initApp();

    function initApp() {
        bindEvents();
        loadAllDashboardData();
        loadPowerBIConfig();
    }

    // Bind UI Event Listeners
    function bindEvents() {
        // Theme Switcher
        document.getElementById("btnThemeToggle").addEventListener("click", toggleTheme);

        // Filter Bar Buttons & Selects
        document.getElementById("btnApplyFilters").addEventListener("click", () => {
            readFilterValues();
            loadAllDashboardData();
        });

        document.getElementById("btnResetFilters").addEventListener("click", () => {
            document.getElementById("filterDepartment").value = "All";
            document.getElementById("filterRisk").value = "All";
            document.getElementById("filterOvertime").value = "All";
            readFilterValues();
            loadAllDashboardData();
        });

        // Tab Switching
        document.querySelectorAll(".nav-tab").forEach(tab => {
            tab.addEventListener("click", (e) => {
                const targetTab = e.currentTarget.getAttribute("data-tab");
                switchTab(targetTab);
            });
        });

        // Employee Directory Search & Pagination
        const searchInput = document.getElementById("directorySearch");
        let searchDebounce = null;
        searchInput.addEventListener("input", (e) => {
            clearTimeout(searchDebounce);
            searchDebounce = setTimeout(() => {
                state.directory.search = e.target.value;
                state.directory.page = 1;
                loadEmployeeDirectory();
            }, 300);
        });

        document.getElementById("btnPrevPage").addEventListener("click", () => {
            if (state.directory.page > 1) {
                state.directory.page--;
                loadEmployeeDirectory();
            }
        });

        document.getElementById("btnNextPage").addEventListener("click", () => {
            state.directory.page++;
            loadEmployeeDirectory();
        });

        // Directory Table Headers Sorting
        document.querySelectorAll("#tab-directory th[data-sort]").forEach(th => {
            th.addEventListener("click", (e) => {
                const col = e.currentTarget.getAttribute("data-sort");
                if (state.directory.sortBy === col) {
                    state.directory.sortOrder = state.directory.sortOrder === "asc" ? "desc" : "asc";
                } else {
                    state.directory.sortBy = col;
                    state.directory.sortOrder = "desc";
                }
                loadEmployeeDirectory();
            });
        });

        // Drawer Close Actions
        document.getElementById("btnCloseDrawer").addEventListener("click", closeEmployeeDrawer);
        document.getElementById("btnCloseDrawerFooter").addEventListener("click", closeEmployeeDrawer);
        document.getElementById("drawerEmployee").addEventListener("click", (e) => {
            if (e.target.id === "drawerEmployee") closeEmployeeDrawer();
        });

        // SQL Terminal Events
        document.getElementById("btnRunSQL").addEventListener("click", executeSQLTerminalQuery);
        document.querySelectorAll(".btn-sql-preset").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const sql = e.currentTarget.getAttribute("data-sql");
                document.getElementById("sqlInput").value = sql;
                executeSQLTerminalQuery();
            });
        });

        // Power BI Tabs
        document.querySelectorAll(".pbi-tab").forEach(pbiTab => {
            pbiTab.addEventListener("click", (e) => {
                const targetPBI = e.currentTarget.getAttribute("data-pbi-tab");
                document.querySelectorAll(".pbi-tab").forEach(t => t.classList.remove("active"));
                e.currentTarget.classList.add("active");

                document.querySelectorAll(".pbi-pane").forEach(p => p.classList.add("hidden"));
                document.getElementById(targetPBI).classList.remove("hidden");
            });
        });

        // DAX Modal
        document.getElementById("btnDAXModal").addEventListener("click", () => {
            document.getElementById("modalDAX").classList.remove("hidden");
        });
        document.getElementById("btnCloseDAX").addEventListener("click", () => {
            document.getElementById("modalDAX").classList.add("hidden");
        });

        // ROI Calculator Inputs
        ["roiHeadcount", "roiAvgSalary", "roiCostPerEmp", "roiReductionPct"].forEach(id => {
            document.getElementById(id).addEventListener("input", calculateROIModel);
        });
    }

    function readFilterValues() {
        state.filters.department = document.getElementById("filterDepartment").value;
        state.filters.riskCategory = document.getElementById("filterRisk").value;
        state.filters.overtime = document.getElementById("filterOvertime").value;
    }

    function getFilterQueryString() {
        const p = new URLSearchParams();
        p.append("department", state.filters.department);
        p.append("riskCategory", state.filters.riskCategory);
        p.append("gender", state.filters.gender);
        p.append("overtime", state.filters.overtime);
        return p.toString();
    }

    function switchTab(tabId) {
        document.querySelectorAll(".nav-tab").forEach(t => t.classList.remove("active"));
        const activeTabBtn = document.querySelector(`.nav-tab[data-tab="${tabId}"]`);
        if (activeTabBtn) activeTabBtn.classList.add("active");

        document.querySelectorAll(".tab-pane").forEach(p => p.classList.add("hidden"));
        const activePane = document.getElementById(tabId);
        if (activePane) activePane.classList.remove("hidden");

        // Specific tab load triggers
        if (tabId === "tab-drivers") {
            loadStatisticalDrivers();
            loadCohortMatrix();
        } else if (tabId === "tab-directory") {
            loadEmployeeDirectory();
        } else if (tabId === "tab-powerbi") {
            renderPowerBISimulatorVisuals();
        } else if (tabId === "tab-roi") {
            calculateROIModel();
        }
    }

    function toggleTheme() {
        const body = document.documentElement;
        if (state.theme === "dark") {
            body.setAttribute("data-theme", "light");
            state.theme = "light";
            document.querySelector(".dark-icon").classList.add("hidden");
            document.querySelector(".light-icon").classList.remove("hidden");
        } else {
            body.setAttribute("data-theme", "dark");
            state.theme = "dark";
            document.querySelector(".light-icon").classList.add("hidden");
            document.querySelector(".dark-icon").classList.remove("hidden");
        }
        // Re-render charts to adapt theme colors
        loadAllDashboardData();
    }

    // Load All Dashboard Data
    function loadAllDashboardData() {
        loadExecutiveKPIs();
        loadDepartmentOverview();
        loadSalaryDistribution();
        loadStatisticalDrivers();
    }

    // 1. Executive KPIs Fetch
    async function loadExecutiveKPIs() {
        try {
            const res = await fetch(`/api/kpis?${getFilterQueryString()}`);
            const data = await res.json();

            document.getElementById("kpiTotalEmployees").textContent = data.totalEmployees.toLocaleString();
            document.getElementById("kpiAttritionRate").textContent = `${data.attritionRate}%`;
            document.getElementById("kpiAttritionSubtext").textContent = `${data.attritionCount} employees departed`;
            document.getElementById("kpiHighRiskCount").textContent = data.highRiskCount;
            document.getElementById("kpiAvgIncome").textContent = `$${data.avgMonthlyIncome.toLocaleString()}`;
            document.getElementById("kpiAvgTenure").textContent = `${data.avgTenureYears} yrs`;
            document.getElementById("kpiSalaryAtRisk").textContent = `$${(data.totalSalaryAtRiskAnnual / 1e6).toFixed(2)}M`;
        } catch (err) {
            console.error("Error loading KPIs:", err);
        }
    }

    // 2. Department Overview Chart & Table
    async function loadDepartmentOverview() {
        try {
            const res = await fetch(`/api/departments?${getFilterQueryString()}`);
            const depts = await res.json();

            // Render Dept Summary Table
            const tbody = document.getElementById("tblDeptSummary");
            tbody.innerHTML = "";

            if (depts.length === 0) {
                tbody.innerHTML = `<tr><td colspan="8" class="p-4 text-center text-muted">No records match current filters.</td></tr>`;
                return;
            }

            depts.forEach(d => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td class="p-3 font-bold text-main flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-indigo-500"></span> ${d.Department}
                    </td>
                    <td class="p-3 text-center">${d.totalEmployees}</td>
                    <td class="p-3 text-center text-rose-400 font-bold">${d.attritionCount}</td>
                    <td class="p-3 text-center font-bold">
                        <span class="badge ${d.attritionRatePct > 20 ? 'badge-rose' : 'badge-amber'}">${d.attritionRatePct}%</span>
                    </td>
                    <td class="p-3 text-right font-mono">$${d.avgIncome.toLocaleString()}</td>
                    <td class="p-3 text-center">${d.avgTenure}</td>
                    <td class="p-3 text-center">${d.avgJobSat} / 4</td>
                    <td class="p-3 text-center text-amber-400 font-bold">${d.highRiskCount}</td>
                `;
                tbody.appendChild(tr);
            });

            // Render Chart.js Dept Attrition Bar Chart
            renderChart("chartDeptAttrition", {
                type: "bar",
                data: {
                    labels: depts.map(d => d.Department),
                    datasets: [{
                        label: "Attrition Rate %",
                        data: depts.map(d => d.attritionRatePct),
                        backgroundColor: "rgba(99, 102, 241, 0.75)",
                        borderColor: "#6366f1",
                        borderWidth: 2,
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: getGridColor() },
                            ticks: { color: getTextColor(), callback: v => v + "%" }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { color: getTextColor() }
                        }
                    }
                }
            });

            // Render Attrition Pie Chart
            const totalStaff = depts.reduce((acc, d) => acc + d.totalEmployees, 0);
            const totalDeparted = depts.reduce((acc, d) => acc + d.attritionCount, 0);
            const totalRetained = totalStaff - totalDeparted;

            renderChart("chartAttritionPie", {
                type: "doughnut",
                data: {
                    labels: ["Retained Staff", "Departed Staff"],
                    datasets: [{
                        data: [totalRetained, totalDeparted],
                        backgroundColor: ["#10b981", "#f43f5e"],
                        borderColor: state.theme === "dark" ? "#111827" : "#ffffff",
                        borderWidth: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: "70%",
                    plugins: {
                        legend: {
                            position: "bottom",
                            labels: { color: getTextColor(), font: { size: 11, weight: "600" } }
                        }
                    }
                }
            });

        } catch (err) {
            console.error("Error loading department breakdown:", err);
        }
    }

    // 3. Salary & Overtime Charts
    async function loadSalaryDistribution() {
        try {
            const res = await fetch(`/api/salary-distribution?${getFilterQueryString()}`);
            const data = await res.json();

            renderChart("chartSalaryDist", {
                type: "line",
                data: {
                    labels: data.map(d => d.SalaryBand),
                    datasets: [{
                        label: "Attrition Rate %",
                        data: data.map(d => d.attritionRatePct),
                        backgroundColor: "rgba(244, 63, 94, 0.15)",
                        borderColor: "#f43f5e",
                        borderWidth: 3,
                        fill: true,
                        tension: 0.35,
                        pointBackgroundColor: "#f43f5e",
                        pointRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: getGridColor() },
                            ticks: { color: getTextColor(), callback: v => v + "%" }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { color: getTextColor() }
                        }
                    }
                }
            });

            // Render Overtime Impact Bar Chart
            renderChart("chartOvertimeImpact", {
                type: "bar",
                data: {
                    labels: ["Overtime: Yes", "Overtime: No"],
                    datasets: [{
                        label: "Attrition Rate %",
                        data: [32.4, 12.8],
                        backgroundColor: ["#f59e0b", "#6366f1"],
                        borderRadius: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: getGridColor() },
                            ticks: { color: getTextColor(), callback: v => v + "%" }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { color: getTextColor() }
                        }
                    }
                }
            });

        } catch (err) {
            console.error("Error loading salary distribution:", err);
        }
    }

    // 4. Statistical Risk Drivers & Hypothesis Tests
    async function loadStatisticalDrivers() {
        try {
            const res = await fetch(`/api/statistical-drivers?${getFilterQueryString()}`);
            const data = await res.json();

            // Render Feature Importance Chart
            if (data.drivers && data.drivers.length > 0) {
                renderChart("chartFeatureImportance", {
                    type: "bar",
                    data: {
                        labels: data.drivers.map(d => d.feature),
                        datasets: [{
                            label: "Relative Importance Weight",
                            data: data.drivers.map(d => d.importance),
                            backgroundColor: "rgba(139, 92, 246, 0.8)",
                            borderColor: "#8b5cf6",
                            borderWidth: 1.5,
                            borderRadius: 6
                        }]
                    },
                    options: {
                        indexAxis: "y",
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: {
                                beginAtZero: true,
                                grid: { color: getGridColor() },
                                ticks: { color: getTextColor() }
                            },
                            y: {
                                grid: { display: false },
                                ticks: { color: getTextColor(), font: { weight: "600" } }
                            }
                        }
                    }
                });
            }

            // Render Hypothesis Testing Cards
            const grid = document.getElementById("statsHypothesisGrid");
            grid.innerHTML = "";

            if (!data.hypothesisTests || data.hypothesisTests.length === 0) {
                grid.innerHTML = `<div class="p-4 text-muted text-xs">Insufficient sample size for hypothesis testing.</div>`;
                return;
            }

            data.hypothesisTests.forEach(test => {
                const card = document.createElement("div");
                card.className = "p-4 rounded-xl bg-surface-subtle border border-subtle flex flex-col justify-between space-y-2";
                card.innerHTML = `
                    <div class="flex items-center justify-between">
                        <span class="font-bold text-main text-xs">${test.factor}</span>
                        <span class="badge ${test.significant ? 'badge-emerald' : 'badge-amber'}">
                            ${test.significant ? 'Statistically Significant' : 'Inconclusive'}
                        </span>
                    </div>
                    <div class="text-[11px] text-muted">Test: <strong>${test.testType}</strong></div>
                    <div class="flex items-center gap-4 text-xs font-mono">
                        <span>Stat: <strong>${test.statistic}</strong></span>
                        <span>p-value: <strong class="${test.significant ? 'text-emerald-400' : 'text-amber-400'}">${test.pValue.toFixed(4)}</strong></span>
                        ${test.oddsRatio ? `<span>Odds Ratio: <strong class="text-cyan-400">${test.oddsRatio}x</strong></span>` : ''}
                    </div>
                    <p class="text-xs text-indigo-300 bg-indigo-500/10 p-2 rounded-lg border border-indigo-500/20 font-medium">
                        <i class="fa-solid fa-lightbulb mr-1"></i> ${test.insight}
                    </p>
                `;
                grid.appendChild(card);
            });

        } catch (err) {
            console.error("Error loading statistical drivers:", err);
        }
    }

    // 5. Cohort Matrix Heatmap
    async function loadCohortMatrix() {
        try {
            const res = await fetch(`/api/cohort-matrix?${getFilterQueryString()}`);
            const data = await res.json();

            const grid = document.getElementById("cohortMatrixGrid");
            grid.innerHTML = "";

            if (!data.matrix || data.matrix.length === 0) return;

            // Render Heatmap Matrix
            let html = `
                <div class="grid grid-cols-4 gap-2 text-center text-xs font-bold text-muted uppercase mb-1">
                    <div>Tenure \\ Promo</div>
                    ${data.promoBins.map(p => `<div>${p}</div>`).join('')}
                </div>
            `;

            data.matrix.forEach(row => {
                html += `<div class="grid grid-cols-4 gap-2 text-center text-xs">`;
                html += `<div class="font-bold text-main self-center text-left pl-2">${row[0].tenure}</div>`;

                row.forEach(cell => {
                    let bg = "bg-emerald-500/20 border-emerald-500/30 text-emerald-300";
                    if (cell.attritionRatePct >= 35) bg = "bg-rose-500/25 border-rose-500/40 text-rose-300 font-extrabold";
                    else if (cell.attritionRatePct >= 20) bg = "bg-amber-500/20 border-amber-500/30 text-amber-300 font-bold";

                    html += `
                        <div class="p-3 rounded-xl border ${bg} flex flex-col justify-center">
                            <span class="text-sm">${cell.attritionRatePct}%</span>
                            <span class="text-[10px] text-muted font-normal">${cell.employeeCount} staff</span>
                        </div>
                    `;
                });
                html += `</div>`;
            });

            grid.innerHTML = html;

        } catch (err) {
            console.error("Error loading cohort matrix:", err);
        }
    }

    // 6. Employee Directory Fetch & Render
    async function loadEmployeeDirectory() {
        try {
            const p = new URLSearchParams();
            p.append("department", state.filters.department);
            p.append("riskCategory", state.filters.riskCategory);
            p.append("overtime", state.filters.overtime);
            p.append("page", state.directory.page);
            p.append("pageSize", state.directory.pageSize);
            p.append("search", state.directory.search);
            p.append("sortBy", state.directory.sortBy);
            p.append("sortOrder", state.directory.sortOrder);

            const res = await fetch(`/api/employees?${p.toString()}`);
            const result = await res.json();

            const tbody = document.getElementById("tblEmployees");
            tbody.innerHTML = "";

            if (result.data.length === 0) {
                tbody.innerHTML = `<tr><td colspan="9" class="p-4 text-center text-muted">No employees found matching criteria.</td></tr>`;
                document.getElementById("dirPaginationInfo").textContent = `Showing 0 of 0 employees`;
                return;
            }

            result.data.forEach(emp => {
                const tr = document.createElement("tr");

                let riskBadgeClass = "badge-emerald";
                if (emp.RiskCategory === "High Risk") riskBadgeClass = "badge-rose";
                else if (emp.RiskCategory === "Medium Risk") riskBadgeClass = "badge-amber";

                tr.innerHTML = `
                    <td class="p-3 font-mono font-bold text-muted">${emp.EmployeeID}</td>
                    <td class="p-3 font-bold text-main">${emp.Name}</td>
                    <td class="p-3 text-muted">${emp.Department}</td>
                    <td class="p-3 font-medium text-main">${emp.JobRole}</td>
                    <td class="p-3 text-right font-mono font-semibold">$${emp.MonthlyIncome.toLocaleString()}</td>
                    <td class="p-3 text-center">
                        <span class="badge ${emp.OverTime === 'Yes' ? 'badge-rose' : 'badge-emerald'}">${emp.OverTime}</span>
                    </td>
                    <td class="p-3 text-center font-bold">
                        <span class="badge ${riskBadgeClass}">${emp.AttritionRiskScore}%</span>
                    </td>
                    <td class="p-3 text-xs text-muted max-w-xs truncate" title="${emp.PrimaryRiskFactor}">
                        ${emp.PrimaryRiskFactor}
                    </td>
                    <td class="p-3 text-center">
                        <button class="btn btn-sm btn-indigo text-[11px] px-2.5 py-1 rounded-lg btn-inspect-emp" data-emp-id="${emp.EmployeeID}">
                            Inspect <i class="fa-solid fa-chevron-right ml-1 text-[9px]"></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });

            // Bind Inspect Profile buttons
            document.querySelectorAll(".btn-inspect-emp").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    const empId = e.currentTarget.getAttribute("data-emp-id");
                    openEmployeeProfileDrawer(empId);
                });
            });

            // Update Pagination UI
            const startRecord = (result.page - 1) * result.pageSize + 1;
            const endRecord = Math.min(result.total, result.page * result.pageSize);
            document.getElementById("dirPaginationInfo").textContent = `Showing ${startRecord} to ${endRecord} of ${result.total} employees`;
            document.getElementById("dirPageNum").textContent = `Page ${result.page} of ${result.totalPages}`;

            document.getElementById("btnPrevPage").disabled = (result.page <= 1);
            document.getElementById("btnNextPage").disabled = (result.page >= result.totalPages);

        } catch (err) {
            console.error("Error loading employee directory:", err);
        }
    }

    // Open Employee Profile Drawer
    async function openEmployeeProfileDrawer(empId) {
        try {
            const res = await fetch(`/api/employee/${empId}`);
            if (!res.ok) return;

            const data = await res.json();
            const emp = data.employee;
            const radar = data.radar;
            const pb = data.playbook;

            // Populate Text Header
            document.getElementById("empAvatar").textContent = emp.Name.split(" ").map(n => n[0]).join("");
            document.getElementById("empDetailName").textContent = emp.Name;
            document.getElementById("empDetailMeta").textContent = `${emp.JobRole} | ${emp.Department}`;

            document.getElementById("empRiskScore").textContent = `${emp.AttritionRiskScore}%`;

            const banner = document.getElementById("empRiskBanner");
            const badge = document.getElementById("empRiskBadge");

            if (emp.RiskCategory === "High Risk") {
                banner.className = "p-4 rounded-2xl mb-6 flex items-center justify-between border bg-rose-500/10 border-rose-500/30 text-rose-400";
                badge.className = "badge badge-rose text-xs px-3 py-1 font-bold";
                badge.textContent = "HIGH FLIGHT RISK";
            } else if (emp.RiskCategory === "Medium Risk") {
                banner.className = "p-4 rounded-2xl mb-6 flex items-center justify-between border bg-amber-500/10 border-amber-500/30 text-amber-400";
                badge.className = "badge badge-amber text-xs px-3 py-1 font-bold";
                badge.textContent = "MEDIUM FLIGHT RISK";
            } else {
                banner.className = "p-4 rounded-2xl mb-6 flex items-center justify-between border bg-emerald-500/10 border-emerald-500/30 text-emerald-400";
                badge.className = "badge badge-emerald text-xs px-3 py-1 font-bold";
                badge.textContent = "LOW RISK";
            }

            // Key Stats
            document.getElementById("empDetailPay").textContent = `$${emp.MonthlyIncome.toLocaleString()}/mo`;
            document.getElementById("empDetailTenure").textContent = `${emp.YearsAtCompany} yrs`;
            document.getElementById("empDetailOvertime").textContent = emp.OverTime;
            document.getElementById("empDetailPromo").textContent = `${emp.YearsSinceLastPromotion} yrs`;

            // Playbook Recommendations
            document.getElementById("empPlaybookTitle").textContent = pb.StrategyTitle;
            document.getElementById("empPlaybookPlan").textContent = pb.ActionPlan;
            document.getElementById("empPlaybookCost").textContent = `$${pb.EstCostPerEmp.toLocaleString()}`;
            document.getElementById("empPlaybookReduction").textContent = `-${pb.ExpectedRiskReductionPct}% Risk`;

            // Render Radar Chart
            renderChart("chartEmpRadar", {
                type: "radar",
                data: {
                    labels: ["Job Sat", "Env Sat", "Work-Life", "Rel Sat", "Involvement"],
                    datasets: [{
                        label: "Satisfaction Score %",
                        data: [
                            radar.JobSatisfaction,
                            radar.EnvironmentSatisfaction,
                            radar.WorkLifeBalance,
                            radar.RelationshipSatisfaction,
                            radar.JobInvolvement
                        ],
                        backgroundColor: "rgba(99, 102, 241, 0.25)",
                        borderColor: "#6366f1",
                        pointBackgroundColor: "#8b5cf6",
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        r: {
                            min: 0,
                            max: 100,
                            ticks: { display: false },
                            grid: { color: getGridColor() },
                            pointLabels: { color: getTextColor(), font: { size: 10, weight: "600" } }
                        }
                    },
                    plugins: { legend: { display: false } }
                }
            });

            // Show Drawer
            document.getElementById("drawerEmployee").classList.remove("hidden");

        } catch (err) {
            console.error("Error fetching employee detail:", err);
        }
    }

    function closeEmployeeDrawer() {
        document.getElementById("drawerEmployee").classList.add("hidden");
    }

    // 7. SQL Terminal Execution
    async function executeSQLTerminalQuery() {
        const queryText = document.getElementById("sqlInput").value.trim();
        const statusEl = document.getElementById("sqlExecutionStatus");

        if (!queryText) return;

        statusEl.textContent = "Executing query...";
        statusEl.className = "text-xs text-amber-400 font-mono";

        const startTime = performance.now();

        try {
            const res = await fetch("/api/sql/run", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ query: queryText })
            });

            const duration = (performance.now() - startTime).toFixed(1);
            const data = await res.json();

            if (!res.ok) {
                statusEl.textContent = `Error: ${data.error}`;
                statusEl.className = "text-xs text-rose-400 font-mono";
                return;
            }

            statusEl.textContent = `Query executed in ${duration}ms (${data.rowCount} rows returned)`;
            statusEl.className = "text-xs text-emerald-400 font-mono";

            // Populate Results Header
            const thead = document.getElementById("tblSQLHeader");
            thead.innerHTML = `<tr>${data.columns.map(c => `<th class="p-3">${c}</th>`).join('')}</tr>`;

            // Populate Results Body
            const tbody = document.getElementById("tblSQLBody");
            tbody.innerHTML = "";

            if (data.results.length === 0) {
                tbody.innerHTML = `<tr><td colspan="${data.columns.length}" class="p-3 text-muted">0 rows returned.</td></tr>`;
                return;
            }

            data.results.forEach(row => {
                const tr = document.createElement("tr");
                tr.innerHTML = data.columns.map(col => `<td class="p-3 text-xs">${row[col] !== null ? row[col] : 'NULL'}</td>`).join('');
                tbody.appendChild(tr);
            });

        } catch (err) {
            statusEl.textContent = `Failed to connect to backend server.`;
            statusEl.className = "text-xs text-rose-400 font-mono";
        }
    }

    // 8. Power BI Simulator Config & Charts
    async function loadPowerBIConfig() {
        try {
            const res = await fetch("/api/powerbi/config");
            const data = await res.json();

            const container = document.getElementById("daxMeasuresContainer");
            container.innerHTML = "";

            data.measures.forEach(m => {
                const div = document.createElement("div");
                div.className = "p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1";
                div.innerHTML = `
                    <div class="text-xs font-bold text-amber-400 flex items-center justify-between">
                        <span>${m.name}</span>
                        <button class="btn-copy-dax text-[10px] text-slate-400 hover:text-slate-200" data-dax="${m.dax}"><i class="fa-solid fa-copy mr-1"></i>Copy DAX</button>
                    </div>
                    <pre class="text-[11px] font-mono text-cyan-300 bg-slate-950 p-2 rounded border border-slate-800/80 overflow-x-auto">${m.dax}</pre>
                    <p class="text-[11px] text-slate-400">${m.desc}</p>
                `;
                container.appendChild(div);
            });

            // Bind copy DAX buttons
            document.querySelectorAll(".btn-copy-dax").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    const code = e.currentTarget.getAttribute("data-dax");
                    navigator.clipboard.writeText(code);
                    e.currentTarget.innerHTML = `<i class="fa-solid fa-check text-emerald-400"></i> Copied!`;
                    setTimeout(() => {
                        e.currentTarget.innerHTML = `<i class="fa-solid fa-copy mr-1"></i>Copy DAX`;
                    }, 2000);
                });
            });

        } catch (err) {
            console.error("Error loading Power BI config:", err);
        }
    }

    async function renderPowerBISimulatorVisuals() {
        try {
            const res = await fetch(`/api/kpis?${getFilterQueryString()}`);
            const kpis = await res.json();

            document.getElementById("pbiKpiTotal").textContent = kpis.totalEmployees.toLocaleString();
            document.getElementById("pbiKpiRate").textContent = `${kpis.attritionRate}%`;
            document.getElementById("pbiKpiHighRisk").textContent = kpis.highRiskCount;
            document.getElementById("pbiKpiExposure").textContent = `$${(kpis.totalSalaryAtRiskAnnual / 1e6).toFixed(2)}M`;

            // PBI Bar
            renderChart("chartPBIBar", {
                type: "bar",
                data: {
                    labels: ["R&D", "Sales", "HR", "Tech", "Product"],
                    datasets: [{
                        label: "Attrition %",
                        data: [18.5, 24.2, 16.0, 21.4, 19.1],
                        backgroundColor: "#f59e0b",
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { grid: { color: "#1e293b" }, ticks: { color: "#94a3b8" } },
                        x: { grid: { display: false }, ticks: { color: "#94a3b8" } }
                    }
                }
            });

            // PBI Donut
            renderChart("chartPBIDonut", {
                type: "doughnut",
                data: {
                    labels: ["High Risk", "Medium Risk", "Low Risk"],
                    datasets: [{
                        data: [kpis.highRiskCount, Math.round(kpis.totalEmployees * 0.35), Math.round(kpis.totalEmployees * 0.6)],
                        backgroundColor: ["#f43f5e", "#f59e0b", "#10b981"],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: "bottom", labels: { color: "#94a3b8" } } }
                }
            });

            // PBI Drivers
            renderChart("chartPBIDrivers", {
                type: "bar",
                data: {
                    labels: ["Overtime Mandate", "Low Job Sat", "Below Market Pay", "Work-Life Stress", "Commute Distance"],
                    datasets: [{
                        label: "Odds Impact",
                        data: [2.8, 2.2, 1.9, 1.6, 1.3],
                        backgroundColor: "#38bdf8",
                        borderRadius: 6
                    }]
                },
                options: {
                    indexAxis: "y",
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { color: "#1e293b" }, ticks: { color: "#94a3b8" } },
                        y: { grid: { display: false }, ticks: { color: "#94a3b8" } }
                    }
                }
            });

            // PBI Comp
            renderChart("chartPBIComp", {
                type: "bar",
                data: {
                    labels: ["<$3k", "$3k-$5k", "$5k-$8k", "$8k-$12k", "$12k+"],
                    datasets: [{
                        label: "Attrition %",
                        data: [31.2, 22.4, 17.5, 12.1, 8.4],
                        backgroundColor: "#818cf8",
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { grid: { color: "#1e293b" }, ticks: { color: "#94a3b8" } },
                        x: { grid: { display: false }, ticks: { color: "#94a3b8" } }
                    }
                }
            });

        } catch (err) {
            console.error("Error rendering Power BI simulator visuals:", err);
        }
    }

    // 9. Retention ROI Calculator Logic
    async function calculateROIModel() {
        const headcount = parseInt(document.getElementById("roiHeadcount").value) || 50;
        const avgSalary = parseInt(document.getElementById("roiAvgSalary").value) || 7500;
        const costPerEmp = parseInt(document.getElementById("roiCostPerEmp").value) || 1500;
        const reductionPct = parseFloat(document.getElementById("roiReductionPct").value) || 30.0;

        document.getElementById("roiReductionVal").textContent = `${reductionPct}% Reduction`;

        try {
            const res = await fetch("/api/retention/calculator", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    highRiskHeadcount: headcount,
                    avgMonthlyIncome: avgSalary,
                    estCostPerEmp: costPerEmp,
                    expectedReductionPct: reductionPct
                })
            });

            const data = await res.json();

            document.getElementById("roiReplaceCost").textContent = `$${data.replacementCostPerEmp.toLocaleString()}`;
            document.getElementById("roiTotalCost").textContent = `$${data.totalProgramCost.toLocaleString()}`;
            document.getElementById("roiStaffSaved").textContent = `${data.expectedRetainedEmployees}`;
            document.getElementById("roiNetSavings").textContent = `$${(data.netSavings / 1e6).toFixed(2)}M`;
            document.getElementById("roiPctBadge").textContent = `+${data.roiPercentage.toLocaleString()}% ROI`;

        } catch (err) {
            console.error("Error calculating ROI model:", err);
        }
    }

    // Helper: Chart.js Canvas Management
    function renderChart(canvasId, config) {
        if (state.charts[canvasId]) {
            state.charts[canvasId].destroy();
        }
        const ctx = document.getElementById(canvasId);
        if (ctx) {
            state.charts[canvasId] = new Chart(ctx, config);
        }
    }

    function getTextColor() {
        return state.theme === "dark" ? "#9ca3af" : "#4b5563";
    }

    function getGridColor() {
        return state.theme === "dark" ? "rgba(255, 255, 255, 0.08)" : "rgba(0, 0, 0, 0.08)";
    }
});
