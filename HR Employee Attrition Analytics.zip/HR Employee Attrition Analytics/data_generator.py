"""
Persona HR - Employee Attrition Data Generator
Generates realistic corporate HR dataset with 1,470 employee records,
matching IBM HR Attrition benchmark standards enriched with realistic workforce metrics.
"""

import os
import random
import sqlite3
import numpy as np
import pandas as pd

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

FIRST_NAMES = [
    "Alexander", "Amara", "Benjamin", "Charlotte", "Daniel", "Elena", "Franklin", "Grace",
    "Henry", "Isabella", "James", "Kavya", "Liam", "Maya", "Nathan", "Olivia",
    "Patrick", "Quinn", "Rachel", "Samuel", "Sophia", "Thomas", "Victoria", "William",
    "Xavier", "Yasmine", "Zachary", "Aarav", "Priya", "Carlos", "Sofia", "Marcus",
    "Aisha", "Dmitri", "Fatima", "Gabriel", "Hana", "Kenji", "Lila", "Mateo"
]

LAST_NAMES = [
    "Anderson", "Bharadwaj", "Chen", "Dubois", "Evans", "Foster", "Gupta", "Hernandez",
    "Ibrahim", "Jackson", "Kumar", "Lopez", "Miller", "Nguyen", "O'Connor", "Patel",
    "Quispe", "Rodriguez", "Smith", "Tanaka", "Uchida", "Vargas", "Williams", "Xu",
    "Yamamoto", "Zhang", "Alvarez", "Baker", "Choi", "Diaz", "Gomez", "Kowalski"
]

DEPARTMENTS_ROLES = {
    "Research & Development": [
        "Research Scientist", "Software Engineer", "Senior Developer", 
        "Laboratory Technician", "Manufacturing Director", "Research Director"
    ],
    "Sales": [
        "Sales Executive", "Sales Representative", "Manager"
    ],
    "Human Resources": [
        "Human Resources", "HR Specialist", "Manager"
    ],
    "Engineering & Tech": [
        "Software Engineer", "Senior Developer", "Tech Lead", "Data Scientist"
    ],
    "Marketing & Product": [
        "Product Manager", "Marketing Specialist", "UX Designer"
    ]
}

EDUCATION_FIELDS = [
    "Life Sciences", "Medical", "Computer Science", "Marketing", "Technical Degree", "Human Resources", "Other"
]

BUSINESS_TRAVEL = ["Non-Travel", "Travel_Rarely", "Travel_Frequently"]
MARITAL_STATUS = ["Single", "Married", "Divorced"]
GENDERS = ["Female", "Male", "Non-Binary"]

def generate_hr_dataset(num_records=1470):
    records = []
    
    for i in range(1, num_records + 1):
        emp_id = f"EMP-{1000 + i}"
        first_name = random.choice(FIRST_NAMES)
        last_name = random.choice(LAST_NAMES)
        name = f"{first_name} {last_name}"
        email = f"{first_name.lower()}.{last_name.lower().replace(' ', '')}@company.com"
        
        dept = random.choice(list(DEPARTMENTS_ROLES.keys()))
        role = random.choice(DEPARTMENTS_ROLES[dept])
        
        age = int(np.random.normal(37, 8))
        age = max(18, min(62, age))
        
        gender = random.choices(GENDERS, weights=[0.46, 0.51, 0.03])[0]
        marital_status = random.choices(MARITAL_STATUS, weights=[0.32, 0.46, 0.22])[0]
        
        education_level = random.choices([1, 2, 3, 4, 5], weights=[0.1, 0.2, 0.4, 0.25, 0.05])[0]
        education_map = {1: "Below College", 2: "College", 3: "Bachelor", 4: "Master", 5: "Doctor"}
        education_str = education_map[education_level]
        
        edu_field = random.choice(EDUCATION_FIELDS)
        
        # Experience metrics
        total_working_years = max(0, min(age - 18, int(np.random.normal(11, 7))))
        years_at_company = max(0, min(total_working_years, int(np.random.exponential(5))))
        years_in_current_role = max(0, min(years_at_company, int(np.random.normal(years_at_company * 0.6, 2))))
        years_since_promotion = max(0, min(years_at_company, int(np.random.exponential(2.5))))
        years_with_manager = max(0, min(years_at_company, int(np.random.normal(years_at_company * 0.5, 2))))
        num_companies = int(np.random.poisson(2.5))
        
        # Base compensation logic based on role & experience
        role_base_income = {
            "Research Director": 15000,
            "Manager": 14000,
            "Manufacturing Director": 12500,
            "Tech Lead": 11000,
            "Product Manager": 10500,
            "Senior Developer": 9500,
            "Sales Executive": 8000,
            "Data Scientist": 8500,
            "Healthcare Representative": 7500,
            "Software Engineer": 6500,
            "Research Scientist": 5500,
            "Marketing Specialist": 5200,
            "UX Designer": 5800,
            "HR Specialist": 5000,
            "Human Resources": 4500,
            "Laboratory Technician": 3800,
            "Sales Representative": 3000
        }
        
        base_salary = role_base_income.get(role, 6000)
        salary_variance = np.random.normal(0, base_salary * 0.12)
        exp_bonus = total_working_years * 350
        monthly_income = int(max(2200, base_salary + salary_variance + exp_bonus))
        
        hourly_rate = int(monthly_income / 160 * random.uniform(0.95, 1.05))
        percent_hike = int(max(11, min(25, np.random.normal(15, 3))))
        stock_option = random.choices([0, 1, 2, 3], weights=[0.4, 0.35, 0.15, 0.1])[0]
        
        # Satisfaction scores (1 to 4)
        env_sat = random.choices([1, 2, 3, 4], weights=[0.15, 0.20, 0.35, 0.30])[0]
        job_sat = random.choices([1, 2, 3, 4], weights=[0.16, 0.20, 0.34, 0.30])[0]
        rel_sat = random.choices([1, 2, 3, 4], weights=[0.12, 0.22, 0.36, 0.30])[0]
        wlb_sat = random.choices([1, 2, 3, 4], weights=[0.09, 0.22, 0.48, 0.21])[0]
        job_involvement = random.choices([1, 2, 3, 4], weights=[0.06, 0.25, 0.54, 0.15])[0]
        
        perf_rating = 3 if percent_hike < 20 else 4
        
        biz_travel = random.choices(BUSINESS_TRAVEL, weights=[0.19, 0.70, 0.11])[0]
        dist_home = int(max(1, min(30, np.random.exponential(8))))
        overtime = random.choices(["Yes", "No"], weights=[0.28, 0.72])[0]
        
        # Empirical Attrition Risk Logit (Probability) tuned for ~16.2% attrition rate benchmark
        logit = -3.2  # baseline intercept
        
        # Overtime effect (+1.35)
        if overtime == "Yes":
            logit += 1.35
            
        # Low Job Satisfaction (+1.1)
        if job_sat == 1:
            logit += 1.15
        elif job_sat == 2:
            logit += 0.45
            
        # Low Environment Satisfaction (+0.8)
        if env_sat == 1:
            logit += 0.8
            
        # Low Work Life Balance (+0.9)
        if wlb_sat == 1:
            logit += 0.9
        elif wlb_sat == 2:
            logit += 0.35
            
        # Distance from home (> 15 miles)
        if dist_home > 15:
            logit += 0.6
            
        # Frequent Business Travel
        if biz_travel == "Travel_Frequently":
            logit += 0.75
            
        # Low Monthly Income relative to role base
        if monthly_income < base_salary * 0.9:
            logit += 0.65
            
        # Years since last promotion (>= 4 years)
        if years_since_promotion >= 4:
            logit += 0.6
            
        # Single Marital status
        if marital_status == "Single":
            logit += 0.4
            
        # Young age (< 28)
        if age < 28:
            logit += 0.45
            
        # Low Stock Option (0)
        if stock_option == 0:
            logit += 0.3
            
        # Sigmoid function for risk probability
        prob = 1 / (1 + np.exp(-logit))
        
        # Attrition classification based on probability
        attrition_bool = random.random() < prob
        attrition_str = "Yes" if attrition_bool else "No"
        
        # Risk score 0 to 100%
        risk_score = float(np.clip(prob * 100, 1.5, 96.5))
        
        if risk_score >= 50:
            risk_category = "High Risk"
        elif risk_score >= 25:
            risk_category = "Medium Risk"
        else:
            risk_category = "Low Risk"
            
        # Primary Risk Factor Determination
        risk_factors = []
        if overtime == "Yes":
            risk_factors.append("Excessive OverTime & Burnout Risk")
        if job_sat <= 2:
            risk_factors.append("Low Job & Role Satisfaction")
        if wlb_sat <= 2:
            risk_factors.append("Poor Work-Life Balance")
        if years_since_promotion >= 4:
            risk_factors.append("Career Stagnation (4+ Yrs without Promotion)")
        if monthly_income < base_salary:
            risk_factors.append("Below-Market Compensation")
        if dist_home > 18:
            risk_factors.append("Long Commute Distance (>18 miles)")
        if biz_travel == "Travel_Frequently":
            risk_factors.append("High Business Travel Stress")
            
        primary_factor = risk_factors[0] if risk_factors else "Normal Workforce Retention Baseline"
        
        records.append({
            "EmployeeID": emp_id,
            "Name": name,
            "Email": email,
            "Age": age,
            "Gender": gender,
            "MaritalStatus": marital_status,
            "Department": dept,
            "JobRole": role,
            "Education": education_str,
            "EducationLevel": education_level,
            "EducationField": edu_field,
            "MonthlyIncome": monthly_income,
            "HourlyRate": hourly_rate,
            "PercentSalaryHike": percent_hike,
            "StockOptionLevel": stock_option,
            "PerformanceRating": perf_rating,
            "EnvironmentSatisfaction": env_sat,
            "JobSatisfaction": job_sat,
            "RelationshipSatisfaction": rel_sat,
            "WorkLifeBalance": wlb_sat,
            "JobInvolvement": job_involvement,
            "TotalWorkingYears": total_working_years,
            "YearsAtCompany": years_at_company,
            "YearsInCurrentRole": years_in_current_role,
            "YearsSinceLastPromotion": years_since_promotion,
            "YearsWithCurrManager": years_with_manager,
            "NumCompaniesWorked": num_companies,
            "BusinessTravel": biz_travel,
            "DistanceFromHome": dist_home,
            "OverTime": overtime,
            "Attrition": attrition_str,
            "AttritionRiskScore": round(risk_score, 1),
            "RiskCategory": risk_category,
            "PrimaryRiskFactor": primary_factor
        })
        
    df = pd.DataFrame(records)
    return df

if __name__ == "__main__":
    df = generate_hr_dataset()
    print(f"Generated {len(df)} employee records.")
    print(f"Attrition Rate: {(df['Attrition'] == 'Yes').mean() * 100:.2f}% (Count: {(df['Attrition'] == 'Yes').sum()})")
