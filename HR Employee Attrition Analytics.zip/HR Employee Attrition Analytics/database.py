"""
Persona HR - Database Engine & SQL Store
Manages SQLite database initialization, table setup, pre-calculated views,
and safe execution of custom SQL queries for the frontend interactive terminal.
"""

import sqlite3
import pandas as pd
import numpy as np
from data_generator import generate_hr_dataset

DB_PATH = "hr_attrition.db"

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    print("Initializing SQLite Database...")
    df = generate_hr_dataset(1470)
    
    conn = sqlite3.connect(DB_PATH)
    
    # Save main employees table
    df.to_sql("employees", conn, if_exists="replace", index=False)
    
    # Create index on key fields for performance
    cursor = conn.cursor()
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_emp_dept ON employees(Department);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_emp_attrition ON employees(Attrition);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_emp_risk ON employees(RiskCategory);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_emp_role ON employees(JobRole);")
    
    # Create Department Metrics summary table
    dept_sql = """
    CREATE TABLE IF NOT EXISTS department_metrics AS
    SELECT 
        Department,
        COUNT(*) as TotalEmployees,
        SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) as AttritionCount,
        ROUND(CAST(SUM(CASE WHEN Attrition = 'Yes' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) * 100, 2) as AttritionRatePct,
        ROUND(AVG(MonthlyIncome), 2) as AvgMonthlyIncome,
        ROUND(AVG(YearsAtCompany), 2) as AvgTenureYears,
        ROUND(AVG(JobSatisfaction), 2) as AvgJobSatisfaction,
        ROUND(AVG(WorkLifeBalance), 2) as AvgWorkLifeBalance,
        SUM(CASE WHEN OverTime = 'Yes' THEN 1 ELSE 0 END) as OvertimeEmployeeCount,
        SUM(CASE WHEN RiskCategory = 'High Risk' THEN 1 ELSE 0 END) as HighRiskCount
    FROM employees
    GROUP BY Department;
    """
    cursor.execute("DROP TABLE IF EXISTS department_metrics;")
    cursor.execute(dept_sql)
    
    # Create Retention Playbook lookup table
    cursor.execute("DROP TABLE IF EXISTS retention_playbook;")
    cursor.execute("""
    CREATE TABLE retention_playbook (
        Id INTEGER PRIMARY KEY AUTOINCREMENT,
        RiskCategory TEXT,
        PrimaryRiskFactor TEXT,
        StrategyTitle TEXT,
        ActionPlan TEXT,
        EstCostPerEmp INTEGER,
        ExpectedRiskReductionPct REAL
    );
    """)
    
    playbook_data = [
        ("High Risk", "Excessive OverTime & Burnout Risk", "Workload Redistribution & Overtime Cap", "Implement mandatory maximum 5hr overtime cap per week and hire seasonal contractors.", 450, 35.0),
        ("High Risk", "Low Job & Role Satisfaction", "Role Re-alignment & Skill Development", "Conduct 1-on-1 career pathing, assign high-impact project mentors, and offer $1,500 training stipend.", 1500, 28.5),
        ("High Risk", "Poor Work-Life Balance", "Flexible Hybrid Work & Wellness Pass", "Offer 2 days remote work flexibility per week and $75/mo wellness reimbursement.", 900, 32.0),
        ("High Risk", "Career Stagnation (4+ Yrs without Promotion)", "Accelerated Promotion Review & Band Raise", "Initiate out-of-cycle performance & level review with clear 6-month promotion milestones.", 3500, 42.0),
        ("High Risk", "Below-Market Compensation", "Market Salary Benchmark Correction", "Adjust base salary to 65th percentile market standard (+8-12% raise).", 4800, 48.0),
        ("High Risk", "Long Commute Distance (>18 miles)", "Transportation Subsidy & Flexible Hours", "Provide $150/mo commute voucher or shift start times outside peak traffic hours.", 1800, 25.0),
        ("Medium Risk", "Normal Workforce Retention Baseline", "Annual Retention Check-in & Recognition", "Conduct annual staying interview, award quarterly merit bonus eligibility.", 500, 15.0),
        ("Low Risk", "Normal Workforce Retention Baseline", "Standard Employee Growth & Engagement", "Maintain standard career pathing and bi-annual performance review.", 200, 5.0)
    ]
    
    cursor.executemany("""
    INSERT INTO retention_playbook (RiskCategory, PrimaryRiskFactor, StrategyTitle, ActionPlan, EstCostPerEmp, ExpectedRiskReductionPct)
    VALUES (?, ?, ?, ?, ?, ?);
    """, playbook_data)
    
    conn.commit()
    conn.close()
    print("Database initialized successfully!")

def execute_query(sql_query, params=()):
    """Executes read-only SQL queries and returns column names + rows."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Simple security check: enforce SELECT statements only
    cleaned_query = sql_query.strip()
    if not cleaned_query.upper().startswith("SELECT") and not cleaned_query.upper().startswith("WITH"):
        conn.close()
        raise ValueError("Only SELECT or WITH (read-only) statements are allowed in the SQL sandbox.")
        
    cursor.execute(cleaned_query, params)
    rows = cursor.fetchall()
    
    columns = [description[0] for description in cursor.description] if cursor.description else []
    results = [dict(row) for row in rows]
    
    conn.close()
    return columns, results

if __name__ == "__main__":
    init_db()
