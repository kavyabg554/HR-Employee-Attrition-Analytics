"""
Persona HR - Employee Attrition Analytics Web Application
Flask backend providing REST APIs for HR Analytics, Statistical Modeling,
SQLite SQL Terminal, Power BI Report Simulator, and Retention ROI Engine.
"""

import os
import io
import csv
import json
import sqlite3
from flask import Flask, render_template, jsonify, request, Response
import pandas as pd

from database import init_db, execute_query, DB_PATH, get_db_connection
from analytics_engine import (
    get_executive_kpis,
    get_department_breakdown,
    get_job_role_breakdown,
    get_statistical_drivers,
    get_cohort_matrix,
    get_salary_attrition_distribution,
    calculate_retention_roi,
    load_employee_data
)

app = Flask(__name__, static_folder="static", template_folder="templates")

# Ensure database exists
if not os.path.exists(DB_PATH):
    init_db()

def parse_filters(req):
    return {
        "department": req.args.get("department", "All"),
        "riskCategory": req.args.get("riskCategory", "All"),
        "gender": req.args.get("gender", "All"),
        "overtime": req.args.get("overtime", "All")
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/kpis", methods=["GET"])
def api_kpis():
    filters = parse_filters(request)
    kpi_data = get_executive_kpis(filters)
    return jsonify(kpi_data)

@app.route("/api/departments", methods=["GET"])
def api_departments():
    filters = parse_filters(request)
    dept_data = get_department_breakdown(filters)
    return jsonify(dept_data)

@app.route("/api/roles", methods=["GET"])
def api_roles():
    filters = parse_filters(request)
    role_data = get_job_role_breakdown(filters)
    return jsonify(role_data)

@app.route("/api/statistical-drivers", methods=["GET"])
def api_statistical_drivers():
    filters = parse_filters(request)
    drivers_data = get_statistical_drivers(filters)
    return jsonify(drivers_data)

@app.route("/api/cohort-matrix", methods=["GET"])
def api_cohort_matrix():
    filters = parse_filters(request)
    matrix_data = get_cohort_matrix(filters)
    return jsonify(matrix_data)

@app.route("/api/salary-distribution", methods=["GET"])
def api_salary_distribution():
    filters = parse_filters(request)
    salary_data = get_salary_attrition_distribution(filters)
    return jsonify(salary_data)

@app.route("/api/employees", methods=["GET"])
def api_employees():
    filters = parse_filters(request)
    df = load_employee_data(filters)
    
    # Search query filter
    search_query = request.args.get("search", "").strip().lower()
    if search_query:
        df = df[
            df["Name"].str.lower().str.contains(search_query) |
            df["EmployeeID"].str.lower().str.contains(search_query) |
            df["JobRole"].str.lower().str.contains(search_query) |
            df["PrimaryRiskFactor"].str.lower().str.contains(search_query)
        ]
        
    # Sorting
    sort_by = request.args.get("sortBy", "AttritionRiskScore")
    sort_order = request.args.get("sortOrder", "desc")
    ascending = (sort_order == "asc")
    
    if sort_by in df.columns:
        df = df.sort_values(by=sort_by, ascending=ascending)
        
    total_records = len(df)
    page = int(request.args.get("page", 1))
    page_size = int(request.args.get("pageSize", 15))
    
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size
    
    paged_records = df.iloc[start_idx:end_idx].to_dict(orient="records")
    
    return jsonify({
        "total": total_records,
        "page": page,
        "pageSize": page_size,
        "totalPages": max(1, (total_records + page_size - 1) // page_size),
        "data": paged_records
    })

@app.route("/api/employee/<emp_id>", methods=["GET"])
def api_employee_detail(emp_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM employees WHERE EmployeeID = ?", (emp_id,))
    row = cursor.fetchone()
    
    if not row:
        conn.close()
        return jsonify({"error": "Employee not found"}), 404
        
    emp = dict(row)
    
    # Fetch matching retention playbook recommendations
    cursor.execute("""
        SELECT StrategyTitle, ActionPlan, EstCostPerEmp, ExpectedRiskReductionPct
        FROM retention_playbook
        WHERE RiskCategory = ? AND PrimaryRiskFactor = ?
        LIMIT 1;
    """, (emp["RiskCategory"], emp["PrimaryRiskFactor"]))
    playbook_row = cursor.fetchone()
    
    if not playbook_row:
        # Fallback query by RiskCategory
        cursor.execute("""
            SELECT StrategyTitle, ActionPlan, EstCostPerEmp, ExpectedRiskReductionPct
            FROM retention_playbook
            WHERE RiskCategory = ?
            LIMIT 1;
        """, (emp["RiskCategory"],))
        playbook_row = cursor.fetchone()
        
    playbook = dict(playbook_row) if playbook_row else {
        "StrategyTitle": "Standard Retention Check-in",
        "ActionPlan": "Schedule quarterly career path alignment.",
        "EstCostPerEmp": 500,
        "ExpectedRiskReductionPct": 15.0
    }
    
    conn.close()
    
    # Construct satisfaction radar scores normalized out of 100
    radar_scores = {
        "JobSatisfaction": emp["JobSatisfaction"] * 25,
        "EnvironmentSatisfaction": emp["EnvironmentSatisfaction"] * 25,
        "WorkLifeBalance": emp["WorkLifeBalance"] * 25,
        "RelationshipSatisfaction": emp["RelationshipSatisfaction"] * 25,
        "JobInvolvement": emp["JobInvolvement"] * 25
    }
    
    return jsonify({
        "employee": emp,
        "radar": radar_scores,
        "playbook": playbook
    })

@app.route("/api/sql/run", methods=["POST"])
def api_sql_run():
    data = request.get_json() or {}
    query = data.get("query", "").strip()
    
    if not query:
        return jsonify({"error": "Query string is empty"}), 400
        
    try:
        columns, results = execute_query(query)
        return jsonify({
            "columns": columns,
            "results": results,
            "rowCount": len(results)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/api/retention/calculator", methods=["POST"])
def api_retention_calculator():
    data = request.get_json() or {}
    headcount = int(data.get("highRiskHeadcount", 50))
    avg_income = int(data.get("avgMonthlyIncome", 7500))
    cost_per_emp = int(data.get("estCostPerEmp", 1500))
    reduction_pct = float(data.get("expectedReductionPct", 30.0))
    
    res = calculate_retention_roi(headcount, avg_income, cost_per_emp, reduction_pct)
    return jsonify(res)

@app.route("/api/powerbi/config", methods=["GET"])
def api_powerbi_config():
    """Provides configuration metadata and sample DAX formulas for the Power BI Embed Simulator."""
    dax_measures = [
        {"name": "Attrition Rate %", "dax": "Attrition Rate % = DIVIDE(COUNTROWS(FILTER('Employees', 'Employees'[Attrition] = \"Yes\")), COUNTROWS('Employees'), 0) * 100", "desc": "Calculates percentage of employees who left the organization."},
        {"name": "High Risk Headcount", "dax": "High Risk Headcount = CALCULATE(COUNTROWS('Employees'), 'Employees'[RiskCategory] = \"High Risk\")", "desc": "Counts employees with Attrition Risk Score >= 50%."},
        {"name": "Annual Salary at Risk", "dax": "Salary at Risk = CALCULATE(SUMX('Employees', 'Employees'[MonthlyIncome] * 12), 'Employees'[RiskCategory] = \"High Risk\")", "desc": "Total annual compensation exposure for high flight risk talent."},
        {"name": "Overtime Attrition Impact Ratio", "dax": "OT Impact Ratio = DIVIDE(CALCULATE(COUNTROWS('Employees'), 'Employees'[Attrition] = \"Yes\", 'Employees'[OverTime] = \"Yes\"), CALCULATE(COUNTROWS('Employees'), 'Employees'[Attrition] = \"Yes\"), 0)", "desc": "Proportion of total attrition driven by overtime workers."},
        {"name": "Avg Tenure (Stayed vs Left)", "dax": "Avg Tenure Delta = AVERAGE('Employees'[YearsAtCompany]) - CALCULATE(AVERAGE('Employees'[YearsAtCompany]), ALL('Employees'))", "desc": "Variance in tenure duration across risk groups."}
    ]
    
    tabs = [
        {"id": "overview", "title": "1. Executive Attrition Overview"},
        {"id": "drivers", "title": "2. Risk Drivers & Statistics"},
        {"id": "compensation", "title": "3. Compensation & Role Matrix"},
        {"id": "retention", "title": "4. Retention Strategy & ROI"}
    ]
    
    return jsonify({"measures": dax_measures, "tabs": tabs})

@app.route("/api/export", methods=["GET"])
def api_export_csv():
    filters = parse_filters(request)
    df = load_employee_data(filters)
    
    output = io.StringIO()
    df.to_csv(output, index=False)
    
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=hr_employee_attrition_data.csv"}
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
